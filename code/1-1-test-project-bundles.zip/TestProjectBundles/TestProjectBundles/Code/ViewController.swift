//
//  ViewController.swift
//  TestProjectBundles
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit
import SubFramework

public class ViewController: UIViewController {

    override public func viewDidLoad() {
        super.viewDidLoad()
        
        let someClass = SomeClass()
        someClass.doSomething()
        
        let currentBundle = Bundle.main
        
        let appBundleByID = Bundle(identifier: "com.e-legion.TestProjectBundles")!
        let appBundleByClass = Bundle(for: ViewController.self)
        
        let frameworkBundleByID = Bundle(identifier: "com.e-legion.SubFramework")!
        let frameworkBundleByClass = Bundle(for: SomeClass.self)
        
        print("current bundle in application \(currentBundle)")
        print("appBundleByID \(appBundleByID)")
        print("appBundleByClass\(appBundleByClass)")
        print("frameworkBundleByID \(frameworkBundleByID)")
        print("frameworkBundleByClass\(frameworkBundleByClass)")
        
        let pathToImage = Bundle.main.path(forResource: "cupcakes", ofType: ".jpg")!
        print("\(pathToImage)")
        
        print("\(Bundle.main.infoDictionary!)")
        print("\(Bundle.main.bundlePath)")
        print("\(Bundle.main.bundleIdentifier!)")
        
        _ = UINib(nibName: "SomeView", bundle: nil)
        
        _ = UIViewController(nibName: nil, bundle: nil)
    }
}
