//
//  SomeClass.swift
//  SubFramework
//
//  Created by Ildar Gilfanov on 15/06/2018.
//  Copyright © 2018 e-Legion. All rights reserved.
//

import Foundation

public class SomeClass {
    public init() {
    }
    
    public func doSomething() {
        let currenctBundle = Bundle.main
        
        let frameworkBundleByID = Bundle(identifier: "com.e-legion.SubFramework")!
        let frameworkBundleByClass = Bundle(for: SomeClass.self)
        
        print("current bundle in framework \(currenctBundle)")
        print("frameworkBundleByID \(frameworkBundleByID)")
        print("frameworkBundleByClass\(frameworkBundleByClass)")
    }
}
