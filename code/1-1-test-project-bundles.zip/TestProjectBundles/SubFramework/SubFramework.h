//
//  SubFramework.h
//  SubFramework
//
//  Created by Ildar Gilfanov on 15/06/2018.
//  Copyright © 2018 e-Legion. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SubFramework.
FOUNDATION_EXPORT double SubFrameworkVersionNumber;

//! Project version string for SubFramework.
FOUNDATION_EXPORT const unsigned char SubFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SubFramework/PublicHeader.h>


