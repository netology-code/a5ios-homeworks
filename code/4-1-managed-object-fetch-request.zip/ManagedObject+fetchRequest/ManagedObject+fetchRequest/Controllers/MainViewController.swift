//
//  ViewController.swift
//  ManagedObject
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import CoreData

class MainViewController: UIViewController {
    
    @IBOutlet private weak var itemsTableView: UITableView!
   
    var dataManager: CoreDataManager!
    private var items = [Item]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //fillDataModel()
        itemsTableView.delegate = self
        itemsTableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        fetchData()
        itemsTableView.reloadData()
    }
    
    @IBAction private func addItemButtonPressed(_ sender: UIBarButtonItem) {
        
        let storyboard = UIStoryboard(name: "ItemViewController", bundle: nil)
        let itemViewController = storyboard.instantiateViewController(withIdentifier: "ItemViewController") as! ItemViewController
        
        itemViewController.dataManager = dataManager
        navigationController?.pushViewController(itemViewController, animated: true)
    }
    
    //17
    @IBAction func searchButtonPressed(_ sender: UIBarButtonItem) {
        
        let searchViewController = SearchViewController()
        searchViewController.delegate = self
        searchViewController.modalTransitionStyle = .crossDissolve
        searchViewController.modalPresentationStyle = .overCurrentContext
        present(searchViewController, animated: true, completion: nil)
    }
    // 15
    private func fetchData(predicate: NSCompoundPredicate? = nil) {
        
        items = dataManager.fetchData(for: Item.self, predicate: predicate)
        if items.count > 0 {
            itemsTableView.isHidden = false
        } else {
            itemsTableView.isHidden = true
        }
    }
    
}

extension MainViewController: UITableViewDelegate {

    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let deleteAction = UITableViewRowAction(style: .destructive, title: "DELETE") {
            deleteAction, indexPath in
            
            self.dataManager.delete(object: self.items[indexPath.row])
            self.fetchData()
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        deleteAction.backgroundColor = UIColor.red
        return [deleteAction]
    }
    
}

extension MainViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemTableViewCell", for: indexPath)
        if let cell = cell as? ItemTableViewCell {
            cell.configureCell(with: items[indexPath.row])
        }
        return cell
    }
}

//16
extension MainViewController: SearchDelegate {
    func viewController(_ viewController: SearchViewController, didPassedData predicate: NSCompoundPredicate) {
        fetchData(predicate: predicate)
        itemsTableView.reloadData()
       
        print(predicate)
    }
    
}

