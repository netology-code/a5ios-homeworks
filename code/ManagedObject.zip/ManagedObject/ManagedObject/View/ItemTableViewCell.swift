//
//  ItemTableViewCell.swift
//  ManagedObject
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class ItemTableViewCell: UITableViewCell {
    
    @IBOutlet weak var itemImageView: UIImageView!
    @IBOutlet weak var itemTitleLabel: UILabel!
    @IBOutlet weak var itemDescriptionLabel: UILabel!
    @IBOutlet weak var itemCategoryLabel: UILabel!
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    // 11
    func configureCell(with item: Item) {
        itemImageView.image = item.image?.image as? UIImage
        itemTitleLabel.text = item.name
        itemDescriptionLabel.text = item.descript
        itemCategoryLabel.text = "Category: " + (item.category?.name)!
        itemPriceLabel.text = "$" + String(format: "%.0f", item.price)
        
    }
    
}
