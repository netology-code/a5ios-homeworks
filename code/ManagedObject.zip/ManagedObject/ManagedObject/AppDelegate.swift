//
//  AppDelegate.swift
//  ManagedObject
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    //9
    let dataManager = CoreDataManager(modelName: "Store")

    //10
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
       
        let storyboard = UIStoryboard(name: "MainViewController", bundle: Bundle.main)
      
        guard let mainViewController = storyboard.instantiateViewController(withIdentifier: "MainViewController") as? MainViewController else {
            return false
        }
        mainViewController.dataManager = dataManager
        
        //Add navigationViewcontroller
        window = UIWindow()
        window?.rootViewController = UINavigationController.init(rootViewController: mainViewController)
        window?.makeKeyAndVisible()
        
        return true
    }

}

