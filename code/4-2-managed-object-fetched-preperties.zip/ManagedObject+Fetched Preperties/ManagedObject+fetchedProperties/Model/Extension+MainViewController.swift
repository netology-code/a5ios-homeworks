//
//  ModelData.swift
//  ManagedObject+fetchRequest
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

extension MainViewController {
    
    func fillDataModel() {
        
        let context = dataManager.getContext()
        
        // MARK: Add storehouse 
        let storehouse = dataManager.createObject(from: Storehouse.self)
        storehouse.name = "main"
        
        // Electronics
        let category = dataManager.createObject(from: Category.self)
        category.name = "Electronics"
        
        let image1 = dataManager.createObject(from: Image.self)
        image1.image = #imageLiteral(resourceName: "macbook retina ")
        let item1 = dataManager.createObject(from: Item.self)
        item1.name = "MacBook Pro 13.3 Retina"
        item1.descript = "Apple MF839LL/A MacBook Pro 13.3-Inch Laptop with Retina Display, 128GB"
        item1.image = image1
        item1.category = category
        item1.price = 1900
        item1.date = Date()
        
        let image2 = dataManager.createObject(from: Image.self)
        image2.image = #imageLiteral(resourceName: "macbook pro 2017")
        let item2 = dataManager.createObject(from: Item.self)
        item2.name = "MacBook Pro 15 Retina"
        item2.descript = "Apple 15 Inch MacBook Pro Laptop (Retina Display, 2.2GHz Intel Core i7, 16GB RAM, 256GB Hard Drive, Intel Iris Pro Graphics) Silver"
        item2.image = image2
        item2.category = category
        item2.price = 2200
        item2.date = Date()
        
        let image3 = dataManager.createObject(from: Image.self)
        image3.image = #imageLiteral(resourceName: "macbook_air_high_sierra")
        let item3 = dataManager.createObject(from: Item.self)
        item3.name = "MacBook Air 13.3"
        item3.descript = "Apple 13.3 MacBook Air (2017) Laptop, Intel Core i5 (Up To 2.9GHz), 8GB RAM, 128GB SSD "
        item3.image = image3
        item3.category = category
        item3.price = 900
        item3.date = Date()
        
        let image4 = dataManager.createObject(from: Image.self)
        image4.image = #imageLiteral(resourceName: "apple watch 3 black")
        let item4 = dataManager.createObject(from: Item.self)
        item4.name = "Apple Watch Series 3 black"
        item4.descript = "Apple Smart Watch 38mm Watch Series 3 - GPS - Space Gray Aluminum Case with Black Sport Band"
        item4.image = image4
        item4.category = category
        item4.price = 399
        item4.date = Date()
        item4.storehouse = "main"
        
        let image5 = dataManager.createObject(from: Image.self)
        image5.image = #imageLiteral(resourceName: "apple watch 3 alum")
        let item5 = dataManager.createObject(from: Item.self)
        item5.name = "Apple Watch Series 3 silver"
        item5.descript = "Apple Smart Watch 38mm Watch Series 3 - GPS - Silver Aluminum Case with Black Sport Band"
        item5.image = image5
        item5.category = category
        item5.price = 399
        item5.date = Date()
        item5.storehouse = "main"
        
        let image6 = dataManager.createObject(from: Image.self)
        image6.image = #imageLiteral(resourceName: "apple watch 3 rgold")
        let item6 = dataManager.createObject(from: Item.self)
        item6.name = "Apple Watch Series 3 gold"
        item6.descript = "Apple Smart Watch 38mm Watch Series 3 - GPS - Gold Aluminum Case with Black Sport Band"
        item6.image = image6
        item6.category = category
        item6.price = 399
        item6.date = Date()
        item6.storehouse = "main"
        
        // Clothes
        let category1 = dataManager.createObject(from: Category.self)
        category1.name = "Clothes"
        
        let image7 = dataManager.createObject(from: Image.self)
        image7.image = #imageLiteral(resourceName: "t1")
        let item7 = dataManager.createObject(from: Item.self)
        item7.name = "T-Shirt Red"
        item7.descript = "Red 100% cotton t-shirt, maid in China"
        item7.image = image7
        item7.category = category1
        item7.price = 9.99
        item7.date = Date()
        
        let image8 = dataManager.createObject(from: Image.self)
        image8.image = #imageLiteral(resourceName: "t2")
        let item8 = dataManager.createObject(from: Item.self)
        item8.name = "T-Shirt Black"
        item8.descript = "Black 100% cotton t-shirt, maid in China"
        item8.image = image8
        item8.category = category1
        item8.price = 9.99
        item8.date = Date()
        
        let image9 = dataManager.createObject(from: Image.self)
        image9.image = #imageLiteral(resourceName: "t3")
        let item9 = dataManager.createObject(from: Item.self)
        item9.name = "T-Shirt White"
        item9.descript = "White 100% cotton t-shirt, maid in China"
        item9.image = image9
        item9.category = category1
        item9.price = 9.99
        item9.date = Date()
        
        //Food&Drink
        let category2 = dataManager.createObject(from: Category.self)
        category2.name = "Food&Drink"
        
        let image10 = dataManager.createObject(from: Image.self)
        image10.image = #imageLiteral(resourceName: "apple")
        let item10 = dataManager.createObject(from: Item.self)
        item10.name = "Apples"
        item10.descript = "Apples Red King, Colorado production"
        item10.image = image10
        item10.category = category2
        item10.price = 2.99
        item10.date = Date()
        
        let image11 = dataManager.createObject(from: Image.self)
        image11.image = #imageLiteral(resourceName: "banana")
        let item11 = dataManager.createObject(from: Item.self)
        item11.name = "Banans"
        item11.descript = "Banans, Brazil production"
        item11.image = image11
        item11.category = category2
        item11.price = 1.99
        item11.date = Date()
        
        let image12 = dataManager.createObject(from: Image.self)
        image12.image = #imageLiteral(resourceName: "pears")
        let item12 = dataManager.createObject(from: Item.self)
        item12.name = "Pears"
        item12.descript = "Pears Florrel, Colorado production"
        item12.image = image12
        item12.category = category2
        item12.price = 2.99
        item12.date = Date()
        
        dataManager.save(context: context)
    }
}
