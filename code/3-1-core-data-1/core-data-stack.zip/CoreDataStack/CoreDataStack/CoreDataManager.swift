//
//  CoreDataManager.swift
//  CoreDataStack
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import CoreData

final class CoreDataManagerOld {
    
    // 1
    private let modelName: String
    
    init(modelName: String) {
        self.modelName = modelName
    }
    
    // MARK: - Core Data Stack
    
    // 2
    private lazy var managedObjectModel: NSManagedObjectModel = {
        // 3
        guard let modelURL = Bundle.main.url(forResource: self.modelName, withExtension: "momd") else {
            fatalError("Unable to Find Data Model")
        }
        //4
        guard let managedObjectModel = NSManagedObjectModel(contentsOf: modelURL) else {
            fatalError("Unable to Load Data Model")
        }
        
        return managedObjectModel
    }()
   
    // 5
    private lazy var persistentStoreCoordinator: NSPersistentStoreCoordinator = {
        // 6
        let persistentStoreCoordinator = NSPersistentStoreCoordinator(managedObjectModel: self.managedObjectModel)
        // 7
        let documentsDirectoryURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        // 8
        let persistentStoreURL = documentsDirectoryURL.appendingPathComponent("\(self.modelName).sqlite")
        
        do {
        //9
            try persistentStoreCoordinator.addPersistentStore(ofType: NSSQLiteStoreType,
                                                              configurationName: nil,
                                                              at: persistentStoreURL,
                                                              options: nil)
        } catch {
            fatalError("Unable to Load Persistent Store")
        }
        
        return persistentStoreCoordinator
    }()
    
    //10
    private(set) lazy var managedObjectContext: NSManagedObjectContext = {
        //11
        let managedObjectContext = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
        // 12
        managedObjectContext.persistentStoreCoordinator = self.persistentStoreCoordinator
        
        return managedObjectContext
    }()
    
   
    
}

final class CoreDataManagerNew {
    
    private let modelName: String
    
    init(modelName: String) {
        self.modelName = modelName
    }
    //13
    lazy var persistentContainer: NSPersistentContainer = {
        //14
        let container = NSPersistentContainer(name: modelName)
        //15
        container.loadPersistentStores(completionHandler: {
            storeDescription, error in
            
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
}
