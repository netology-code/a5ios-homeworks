//
//  ViewController.swift
//  CoreDataStack
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    var dataManager: CoreDataManagerNew?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //21
        guard let context = dataManager?.persistentContainer.viewContext else {
            return
        }
        print(context)
    }

}
