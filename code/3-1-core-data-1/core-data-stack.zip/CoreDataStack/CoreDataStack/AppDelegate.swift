//
//  AppDelegate.swift
//  CoreDataStack
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        //16
        let dataManager = CoreDataManagerNew(modelName: "CoreDataModel")
        //17
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        //18
        guard let initialviewController = storyboard.instantiateInitialViewController() as? ViewController else {
            fatalError("Unable to Configure Initial View Controller")
        }
        //19
        initialviewController.dataManager = dataManager
        //20
        window?.rootViewController = initialviewController
        
        return true
    }
    
}

