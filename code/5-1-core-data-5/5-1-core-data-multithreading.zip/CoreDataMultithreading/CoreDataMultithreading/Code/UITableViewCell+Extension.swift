import UIKit

fileprivate let dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .full
    formatter.timeStyle = .medium
    return formatter
}()

extension UITableViewCell {
    func configure(order: Order) {
        self.textLabel?.text = String(order.number)
        self.detailTextLabel?.text = dateFormatter.string(from: order.createdAt)
    }
}
