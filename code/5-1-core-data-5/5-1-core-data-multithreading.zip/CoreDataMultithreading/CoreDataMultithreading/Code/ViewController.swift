import UIKit
import CoreData

class ViewController: UIViewController {
    
    private struct Const {
        static let cellIdentifier = "cellIdentifier"
        static let maxNumberOfOrders = 20
    }
    
    @IBOutlet private var tableView: UITableView!
    
    // 1
    private lazy var coreDataStack: CoreDataStackable = {
        let stackFactory = CoreDataStackFactory()
        return stackFactory.createCoreDataStack(type: CoreDataStackType.separate)
//        return stackFactory.createCoreDataStack(type: CoreDataStackType.nested)
    }()
    
    // 2
    fileprivate(set) lazy var fetchResultsController: NSFetchedResultsController<Order> = {
        let frc = NSFetchedResultsController(fetchRequest: Order.sortedFetchRequest,
                                             managedObjectContext: coreDataStack.viewContext,
                                             sectionNameKeyPath: nil,
                                             cacheName: nil)
        frc.delegate = self
        return frc
    }()
    
    // 3
    private lazy var refreshControl: UIRefreshControl = {
        let refresh = UIRefreshControl()
        refresh.addTarget(self, action: #selector(refreshControlHandler(sender:)), for: .valueChanged)
        return refresh
    }()
    
    // MARK: - Life cycle
    
    // 4
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        try? fetchResultsController.performFetch()
        tableView.refreshControl = refreshControl
    }
    
    // MARK: - Actions
    
    // 6
    @objc
    private func refreshControlHandler(sender: UIRefreshControl) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        print("start Refreshing")
        
        DispatchQueue.global(qos: .userInteractive).async { [weak self] in
            for i in 0..<Const.maxNumberOfOrders {
                autoreleasepool {
                    let orderNumber = Int64(Date().timeIntervalSince1970 + Double(i))
                    self?.coreDataStack.insert(orderNumber: orderNumber)
                }
            }
            self?.coreDataStack.saveChanges {
                DispatchQueue.main.async { [weak self] in
                    UIApplication.shared.isNetworkActivityIndicatorVisible = false
                    self?.refreshControl.endRefreshing()
                    print("end Refreshing")
                }
            }
        }
    }
    
    // 7
    @IBAction func deleteAllOrders(sender: UIBarButtonItem) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        print("start Deleting")
        
        DispatchQueue.global(qos: .userInteractive).async { [weak self] in
            self?.coreDataStack.clearAll()
            self?.coreDataStack.saveChanges {
                DispatchQueue.main.async {
                    UIApplication.shared.isNetworkActivityIndicatorVisible = false
                    print("end Deleting")
                }
            }
        }
    }
}

// 8
extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let section = fetchResultsController.sections?[section] else {
            return 0
        }
        
        return section.numberOfObjects
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Const.cellIdentifier, for: indexPath)
        
        let order = fetchResultsController.object(at: indexPath)
        cell.configure(order: order)
        
        return cell
    }
}

// 9
extension ViewController: NSFetchedResultsControllerDelegate {
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        switch type {
        case .insert:
            guard let indexPath = newIndexPath else {
                fatalError("Index path should be not nil")
            }
            tableView.insertRows(at: [indexPath], with: .left)
        case .update:
            guard let indexPath = indexPath else {
                fatalError("Index path should be not nil")
            }
            
            guard let cell = tableView.cellForRow(at: indexPath) else {
                break
            }
            let order = fetchResultsController.object(at: indexPath)
            cell.configure(order: order)
        case .move:
            guard let indexPath = indexPath else {
                fatalError("Index path should be not nil")
            }
            
            guard let newIndexPath = newIndexPath else {
                fatalError("New index path should be not nil")
            }
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.insertRows(at: [newIndexPath], with: .fade)
        case .delete:
            guard let indexPath = indexPath else {
                fatalError("Index path should be not nil")
            }
            tableView.deleteRows(at: [indexPath], with: .right)
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        tableView.endUpdates()
    }
}
