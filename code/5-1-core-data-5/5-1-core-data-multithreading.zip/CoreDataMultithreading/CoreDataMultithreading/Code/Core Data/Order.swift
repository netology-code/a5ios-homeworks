import Foundation
import CoreData

class Order: NSManagedObject {
    @NSManaged fileprivate(set) var createdAt: Date
    @NSManaged fileprivate(set) var number: Int64
}

extension Order {
    private struct Const {
        static let entityName = "Order"
        static let sortDescriptorKey = "createdAt"
    }
    // 1
    static var sortedFetchRequest: NSFetchRequest<Order> {
        let request = NSFetchRequest<Order>(entityName: Const.entityName)
        let sortDescriptor = NSSortDescriptor(key: Const.sortDescriptorKey, ascending: false)
        request.sortDescriptors = [sortDescriptor]
        request.resultType = .managedObjectResultType
        return request
    }
    // 2
    @discardableResult
    static func insert(into context: NSManagedObjectContext, number: Int64) -> Order {
        let order: Order = context.insertObject()
        
        order.number = number
        order.createdAt = Date()
        
        return order
    }
}
