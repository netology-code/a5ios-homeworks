import Foundation
import CoreData

struct Const {
    static let dataModelName = "CoreDataModel"
    static let storeName = "CoreDataModel.sqlite"
}

protocol CoreDataStackable: class {
    typealias NotificationClosure = (_ notification: Notification) -> Void
    typealias SaveCompletionClosure = () -> Void
    // 1
    var viewContext: NSManagedObjectContext! { get }
    // 2
    var backgroundContext: NSManagedObjectContext! { get }
    // 3
    func createStack()
    // 4
    func insert(orderNumber: Int64)
    // 5
    func clearAll()
    // 6
    func saveChanges(completion: @escaping SaveCompletionClosure)
}
