import Foundation
import CoreData

class NestedContextStack: CoreDataStackable {
    var viewContext: NSManagedObjectContext!
    var backgroundContext: NSManagedObjectContext!
    
    private lazy var applicationDocumentsDirectoryURL: URL = {
        guard let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).last else {
            fatalError("Unable to resolve document directory")
        }
        return url
    }()
    
    private lazy var storeURL: URL = {
        applicationDocumentsDirectoryURL.appendingPathComponent(Const.storeName)
    }()
    
    private lazy var managedObjectModelURL: URL = {
        guard let url = Bundle.main.url(forResource: Const.dataModelName, withExtension: "momd") else {
            fatalError("Error loading model from bundle")
        }
        return url
    }()
    
    private lazy var managedObjectModel: NSManagedObjectModel = {
        guard let model = NSManagedObjectModel(contentsOf: managedObjectModelURL) else {
            fatalError("Error initializing mom from: \(Const.dataModelName)")
        }
        return model
    }()
    
    private lazy var persistentStoreCoordinator: NSPersistentStoreCoordinator = {
        return NSPersistentStoreCoordinator(managedObjectModel: managedObjectModel)
    }()
    
    // MARK: - CoreDataStackable
    
    // 1
    func createStack() {
        do {
            try persistentStoreCoordinator.addPersistentStore(ofType: NSSQLiteStoreType, configurationName: nil, at: storeURL, options: nil)
            
            // 2
            backgroundContext = NSManagedObjectContext(concurrencyType: .privateQueueConcurrencyType)
            backgroundContext.persistentStoreCoordinator = persistentStoreCoordinator
            
            // 3
            viewContext = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
            viewContext.parent = backgroundContext
        } catch {
            fatalError("Error create store: \(error)")
        }
    }
    
    // 4
    func insert(orderNumber: Int64) {
        viewContext.performChanges {
            Order.insert(into: self.viewContext, number: orderNumber)
        }
    }
    
    // 5
    func clearAll() {
        viewContext.performChanges {
            guard let orders = try? self.viewContext.fetch(Order.sortedFetchRequest) else {
                return
            }
            
            orders.forEach { self.viewContext.delete($0) }
        }
    }
    
    // 6
    func saveChanges(completion: @escaping SaveCompletionClosure) {
        viewContext.saveOrRollback {
            self.backgroundContext.saveOrRollback {
                completion()
            }
        }
    }
}
