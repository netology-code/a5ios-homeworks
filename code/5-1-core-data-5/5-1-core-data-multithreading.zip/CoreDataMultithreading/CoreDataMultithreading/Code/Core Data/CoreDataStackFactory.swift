import Foundation
import CoreData

enum CoreDataStackType {
    case separate
    case nested
}

class CoreDataStackFactory {
    // 1
    func createCoreDataStack(type: CoreDataStackType) -> CoreDataStackable {
        switch type {
        case .separate:
            let stack = SeparateContextsStack()
            stack.createStack()
            return stack
        case .nested:
            let stack = NestedContextStack()
            stack.createStack()
            return stack
        }
    }
}
