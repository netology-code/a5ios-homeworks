import Foundation
import CoreData

class SeparateContextsStack: CoreDataStackable {
    // 1
    fileprivate(set) var persistentContainer: NSPersistentContainer
    var viewContext: NSManagedObjectContext!
    var backgroundContext: NSManagedObjectContext!
    
    // MARK: - Init
    
    // 2
    init() {
        persistentContainer = NSPersistentContainer(name: Const.dataModelName)
    }
    
    // MARK: - CoreDataStackable
    
    func createStack() {
        // 3
        persistentContainer.loadPersistentStores { [weak self] (_, error) in
            guard error == nil else {
                fatalError("Failed to load store: \(error!)")
            }
            
            // 4
            self?.viewContext = self?.persistentContainer.viewContext
            self?.backgroundContext = self?.persistentContainer.newBackgroundContext()
            
            // 6
            let notificationClosure: NotificationClosure = { [weak self] notification in
                self?.viewContext.performMergeChangesFromContextDidSaveNotification(notification: notification)
            }
            
            // 5
            NotificationCenter.default.addObserver(forName: .NSManagedObjectContextDidSave,
                                                   object: self?.backgroundContext,
                                                   queue: nil,
                                                   using: notificationClosure)
        }
    }
    
    // 7
    func insert(orderNumber: Int64) {
        backgroundContext.performChanges {
            Order.insert(into: self.backgroundContext, number: orderNumber)
        }
    }
    
    // 8
    func clearAll() {
        backgroundContext.performChanges {
            guard let orders = try? self.backgroundContext.fetch(Order.sortedFetchRequest) else {
                return
            }
            
            orders.forEach { self.backgroundContext.delete($0) }
        }
    }
    
    // 9
    func saveChanges(completion: @escaping SaveCompletionClosure) {
        backgroundContext.saveOrRollback {
            completion()
        }
    }
}
