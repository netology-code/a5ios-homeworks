//
//  ItemViewController.swift
//  ManagedObject
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import CoreData

class ItemViewController: UIViewController {
    
    struct Constants {
        static let itemCategories = ["Food&Drink", "Clothes", "Electronics", "Tools", "Books", "Business", "Lifestyle", "Sports"]
    }
    
    @IBOutlet private weak var itemTitleTextField: UITextField!
    @IBOutlet private weak var itemPriceTextField: UITextField!
    @IBOutlet private weak var itemDescriptionTextField: UITextField!
    @IBOutlet private weak var categoryPickerView: UIPickerView!
    @IBOutlet private weak var selectCategoryButton: UIButton!
    @IBOutlet private weak var saveItemButton: UIButton!
    @IBOutlet private weak var itemImageView: UIImageView!
    
    private var imagePickerController = UIImagePickerController()
    private var chosenImage = #imageLiteral(resourceName: "icon")
    private var selectedCategory: String!
    var dataManager: CoreDataManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    @IBAction func addImageButtonPressed(_ sender: UIButton) {
        present(imagePickerController, animated: true, completion: nil)
    }
    
    @IBAction func selectCategoryButtonPressed(_ sender: UIButton) {
        categoryPickerView.isHidden = false
    }

    @IBAction func saveItemButtonPressed(_ sender: UIButton) {
        let context = dataManager.getContext()
        
        let image = dataManager.createObject(from: Image.self)
        image.image = chosenImage
        
        let category = dataManager.createObject(from: Category.self)
        category.name = selectedCategory
        
        let item = dataManager.createObject(from: Item.self)
        item.name = itemTitleTextField.text
        item.descript = itemDescriptionTextField.text
        item.date = Date()
        item.price = (itemPriceTextField.text! as NSString).doubleValue
        item.image = image
        item.category = category
    
        dataManager.save(context: context)
        navigationController?.popViewController(animated: true)
    }
  
    private func setupUI() {
        disableSaveItemButton()
        categoryPickerView.isHidden = true
        categoryPickerView.dataSource = self
        categoryPickerView.delegate = self
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
    }
    
    private func disableSaveItemButton() {
        saveItemButton.isEnabled = false
        saveItemButton.alpha = 0.5
    }
    
    private func enableSaveItemButton() {
        guard let title = itemTitleTextField.text, let price = itemPriceTextField.text else {
            return
        }
        
        if !title.isEmpty && !price.isEmpty {
            saveItemButton.isEnabled = true
            saveItemButton.alpha = 1
        }
    }
}

extension ItemViewController: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectCategoryButton.setTitle(Constants.itemCategories[row], for: .normal)
        selectedCategory = Constants.itemCategories[row]
        categoryPickerView.isHidden = true
        enableSaveItemButton()
    }
}

extension ItemViewController: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return Constants.itemCategories.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return Constants.itemCategories[row]
    }
}

extension ItemViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        guard let image = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            return
        }
        chosenImage = image
        itemImageView.image = chosenImage
        
        defer {
            imagePickerController.dismiss(animated: true, completion: nil)
        }
    }
}
