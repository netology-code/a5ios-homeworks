//
//  ViewController.swift
//  ManagedObject
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit
import CoreData

class MainViewController: UIViewController {
    
    @IBOutlet private weak var itemsTableView: UITableView!
    
    var dataManager: CoreDataManager!
    //9
    var fetchedResultController: NSFetchedResultsController<Item>!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //fillDataModel()
        itemsTableView.delegate = self
        itemsTableView.dataSource = self
        fetchData()
    }
    
    @IBAction private func addItemButtonPressed(_ sender: UIBarButtonItem) {
        
        let storyboard = UIStoryboard(name: "ItemViewController", bundle: nil)
        let itemViewController = storyboard.instantiateViewController(withIdentifier: "ItemViewController") as! ItemViewController
        
        itemViewController.dataManager = dataManager
        navigationController?.pushViewController(itemViewController, animated: true)
    }
    
    
    @IBAction func searchButtonPressed(_ sender: UIBarButtonItem) {
        
        let searchViewController = SearchViewController()
        searchViewController.delegate = self
        searchViewController.modalTransitionStyle = .crossDissolve
        searchViewController.modalPresentationStyle = .overCurrentContext
        present(searchViewController, animated: true, completion: nil)
    }
    
    //10
    private func fetchData(predicate: NSCompoundPredicate? = nil) {
        
        fetchedResultController = dataManager.fetchDataWithController(for: Item.self, sectionNameKeyPath: "category.name", predicate: predicate)
        //11
        fetchedResultController.delegate = self
        fetchedObjectsCheck()
        
    }
    //12
    private func fetchedObjectsCheck() {
        guard let objects = fetchedResultController.fetchedObjects else {
            return
        }
        
        if objects.count > 0 {
            itemsTableView.isHidden = false
        } else {
            itemsTableView.isHidden = true
        }
    }
}

// MARK: UITableViewDelegate

extension MainViewController: UITableViewDelegate {
    // 21
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let deleteAction = UITableViewRowAction(style: .destructive, title: "DELETE") {
            deleteAction, indexPath in
            //22
            let item = self.fetchedResultController.object(at: indexPath)
            self.dataManager.delete(object: item)

        }
        deleteAction.backgroundColor = UIColor.red
        return [deleteAction]
    }
    
}
// MARK: UITableViewDataSource

extension MainViewController: UITableViewDataSource {
    //13
    func numberOfSections(in tableView: UITableView) -> Int {
        guard let sections = fetchedResultController.sections else {
            return 0
        }
        return sections.count
    }
    //14
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        guard let sections = fetchedResultController.sections else {
            return nil
        }
        return sections[section].name
    }
    //15
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let sections = fetchedResultController.sections else {
            return 0
        }
        return sections[section].numberOfObjects
    }
    //16
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemTableViewCell", for: indexPath)
        if let cell = cell as? ItemTableViewCell {
            let item = fetchedResultController.object(at: indexPath)
            cell.configureCell(with: item)
        }
        return cell
    }
}

// MARK: NSFetchedResultsControllerDelegate

extension MainViewController: NSFetchedResultsControllerDelegate {
    //17
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        itemsTableView.beginUpdates()
    }
    //18
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType) {

        switch type {
        case .insert:
            itemsTableView.insertSections(NSIndexSet(index: sectionIndex) as IndexSet, with: .fade)
        case .delete:
            itemsTableView.deleteSections(NSIndexSet(index: sectionIndex) as IndexSet, with: .fade)
        default:
            return
        }

    }
    //19
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        
        switch type {
        case .insert:
            if let indexPath = newIndexPath {
                itemsTableView.insertRows(at: [indexPath], with: .fade)
                fetchedObjectsCheck()
            }
            
        case .delete:
            if let indexPath = indexPath {
                itemsTableView.deleteRows(at: [indexPath], with: .fade)
                fetchedObjectsCheck()
            }
            
        case .update:
            if let indexPath = indexPath {
                let cell = itemsTableView.cellForRow(at: indexPath) as! ItemTableViewCell
                let item = fetchedResultController.object(at: indexPath as IndexPath)
                cell.configureCell(with: item)
            }

        case .move:
            if let indexPath = indexPath {
                itemsTableView.deleteRows(at: [indexPath], with: .fade)
            }
            if let indexPath = newIndexPath {
                itemsTableView.insertRows(at: [indexPath], with: .fade)
            }
        }
      
    }
    //20
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
        itemsTableView.endUpdates()
    }
}

extension MainViewController: SearchDelegate {
    func viewController(_ viewController: SearchViewController, didPassedData predicate: NSCompoundPredicate) {
        fetchData(predicate: predicate)
        itemsTableView.reloadData()
    }
    
}
