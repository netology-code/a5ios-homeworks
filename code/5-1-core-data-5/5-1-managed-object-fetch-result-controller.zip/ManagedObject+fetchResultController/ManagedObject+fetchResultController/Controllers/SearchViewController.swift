//
//  SearchViewController.swift
//  ManagedObject+fetchRequest
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

protocol SearchDelegate: class {
    func viewController(_ viewController: SearchViewController, didPassedData predicate: NSCompoundPredicate)
}

class SearchViewController: UIViewController {
    
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var descriptionTextField: UITextField!
    @IBOutlet weak var priceTextField: UITextField!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var selectCategoryButton: UIButton!
    @IBOutlet weak var viewWithPickerView: UIView!
    @IBOutlet weak var categoryPickerView: UIPickerView!
    
    weak var delegate: SearchDelegate?
    private var selectedCategory = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewWithPickerView.isHidden = true
        categoryPickerView.delegate = self
        categoryPickerView.dataSource = self
        let closeTap = UITapGestureRecognizer(target: self, action: #selector(SearchViewController.closeTapGesture(_:)))
        bgView.addGestureRecognizer(closeTap)
    }
    
    @IBAction func selectCategoryButtonPressed(_ sender: UIButton) {
      viewWithPickerView.isHidden = false
    }
    
    @IBAction func startSearchButtonPressed(_ sender: UIButton) {
        
        let compoundPredicate = makeCompoundPredicate(name: titleTextField.text!, description: descriptionTextField.text!, price: priceTextField.text!, category: selectedCategory)
        delegate?.viewController(self, didPassedData: compoundPredicate)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    @IBAction func resetButtonPressed(_ sender: UIButton) {
        delegate?.viewController(self, didPassedData: NSCompoundPredicate(andPredicateWithSubpredicates: []))
        
        dismiss(animated: true, completion: nil)
    }
    
    private func makeCompoundPredicate(name: String, description: String, price: String, category: String) -> NSCompoundPredicate {
        
        var predicates = [NSPredicate]()
        
        if !name.isEmpty {
            let namePredicate = NSPredicate(format: "name CONTAINS[cd] '\(name)'")
            predicates.append(namePredicate)
        }
        
        if !description.isEmpty {
            let descriptionPredicate = NSPredicate(format: "descript CONTAINS[cd] '\(description)'")
            predicates.append(descriptionPredicate)
        }
        
        if !category.isEmpty {
             let categoryPredicate = NSPredicate(format: "category.name CONTAINS[cd] '\(category)'")
            predicates.append(categoryPredicate)
        }
            
        if !price.isEmpty {
            let selectedSegmentControl = priceSearchCondition(index: segmentedControl.selectedSegmentIndex)
            let pricePredicate = NSPredicate(format: "price \(selectedSegmentControl) '\(price)'")
            predicates.append(pricePredicate)
        }
        
        return NSCompoundPredicate(andPredicateWithSubpredicates: predicates)
    }
    
    private func priceSearchCondition(index: Int) -> String {
        var condition: String!
        
        switch index {
        case 0: condition = ">="
        case 1: condition = "="
        case 2: condition = "<="
        default: break
        }
        return condition
    }
    
    @objc func closeTapGesture (_ recognizer: UITapGestureRecognizer) {
        dismiss(animated: true, completion: nil)
    }
}

extension SearchViewController: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectCategoryButton.setTitle(ItemViewController.Constants.itemCategories[row], for: .normal)
        selectedCategory = ItemViewController.Constants.itemCategories[row]
        viewWithPickerView.isHidden = true
    }
}

extension SearchViewController: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return ItemViewController.Constants.itemCategories.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return ItemViewController.Constants.itemCategories[row]
    }
}
