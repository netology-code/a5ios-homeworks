//
//  RoudedCornerView.swift
//  ManagedObject+fetchRequest
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class RoudedCornerView: UIView {

    override func awakeFromNib() {
        super.awakeFromNib()
        setUpView()
    }
    
    private func setUpView () {
        layer.cornerRadius = 10.0
        clipsToBounds = true
    }

}
