//
//  ViewController.swift
//  FileManager
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // 3
    let fileManager = FileManagerService()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 1
        print(NSHomeDirectory())
    }

    //2 MARK: Tap handlers
    
    @IBAction func getListOfFilesButtonPresse(_ sender: UIButton) {
        fileManager.listFiles(in: .Documents)
    }
    
    @IBAction func writeFileButtonPressed(_ sender: UIButton) {
        let fileText = "Hello my dear friends!"
        fileManager.writeFile(containing: fileText, to: .Documents, withName: "hello.txt")
    }
    
    @IBAction func readFileButtonPressed(_ sender: UIButton) {
        fileManager.readFile(at: .Documents, withName: "hello.txt")
    }
    
    @IBAction func renameFileButtonPressed(_ sender: UIButton) {
        fileManager.renameFile(at: .Documents, with: "hello.txt", to: "helloFriends.txt")
    }
    
    
    @IBAction func copyFileButtonPressed(_ sender: UIButton) {
        fileManager.copyFile(withName: "helloFriends.txt", inDerectory: .Documents, toDerectory: .Inbox)
    }
    
    
    @IBAction func moveFileButtonPressed(_ sender: UIButton) {
        fileManager.moveFile(withName: "helloFriends.txt", inDerectory: .Inbox, toDerectory: .Tmp)
    }
    
    @IBAction func deleteFileButtonPressed(_ sender: UIButton) {
        fileManager.deleteFile(at: .Tmp, withName: "helloFriends.txt")
    }
    
}

