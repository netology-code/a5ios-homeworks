//
//  FileManager.swift
//  FileManager
//
//  Copyright © 2018 E-legion. All rights reserved.
//

import Foundation

// 5
struct FileManagerService {
    
    // 4
    enum AppDirectories : String {
        case Documents = "Documents"
        case Inbox = "Inbox"
        case Library = "Library"
        case Tmp = "tmp"
    }
    
    // MARK: Public
    //11
    func listFiles(in directory: AppDirectories) {
        
        guard let directoryPath = getURL(for: directory)?.path,
            //12
            let directory = try? FileManager.default.contentsOfDirectory(atPath: directoryPath) else {
                return
        }
        
        print("\n----------------------------")
        print("LISTING: \(directoryPath)")
        print("")
        for file in directory {
            print("File: \(file.debugDescription)")
        }
        print("")
        print("----------------------------\n")
        
    }
    //13
    func writeFile(containing: String, to path: AppDirectories, withName name: String) {
        let filePath = (getURL(for: path)?.path)! + "/" + name
        let rawData: Data? = containing.data(using: .utf8)
        FileManager.default.createFile(atPath: filePath, contents: rawData, attributes: nil)
    }
    //14
    func readFile(at path: AppDirectories, withName name: String) {
        let filePath = (getURL(for: path)?.path)! + "/" + name
        
        guard let fileContent = FileManager.default.contents(atPath: filePath),
            let fileContentEncoded = String(bytes: fileContent, encoding: .utf8) else {
                return
        }
        
        print(fileContentEncoded)
    }
    //15
    func deleteFile(at path: AppDirectories, withName name: String) {
        guard let filePath = getURL(for: path)?.appendingPathComponent(name) else {
            return
        }
        try? FileManager.default.removeItem(at: filePath)
    }
    //16
    func renameFile(at path: AppDirectories, with oldName: String, to newName: String) {
        guard let oldPath = getURL(for: path)?.appendingPathComponent(oldName),
            let newPath = getURL(for: path)?.appendingPathComponent(newName) else {
                return
        }
        try? FileManager.default.moveItem(at: oldPath, to: newPath)
    }
    //17
    func moveFile(withName name: String, inDerectory: AppDirectories, toDerectory: AppDirectories) {
        guard let oldPath = getURL(for: inDerectory)?.appendingPathComponent(name),
            let newPath = getURL(for: toDerectory)?.appendingPathComponent(name) else {
                return
        }
        try? FileManager.default.moveItem(at: oldPath, to: newPath)
    }
    //18
    func copyFile(withName name: String, inDerectory: AppDirectories, toDerectory: AppDirectories) {
        guard let oldPath = getURL(for: inDerectory)?.appendingPathComponent(name),
            let newPath = getURL(for: toDerectory)?.appendingPathComponent(name) else {
                return
        }
        try? FileManager.default.copyItem(at: oldPath, to: newPath)
    }
    
    
    // MARK: Private
    // 6
    private func getURL(for directory: AppDirectories) -> URL? {
        
        switch directory {
        case .Documents:
            //7
            guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
                return nil
            }
            return documents
            
        case .Inbox:
            //8
            guard let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(AppDirectories.Inbox.rawValue) else {
                return nil
            }
            
            //9
            if FileManager.default.fileExists(atPath: "\(url)") {
            } else {
                //10
                try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: false, attributes: nil)
            }
            
            return url
            
        case .Library:
            guard let library = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask).first else {
                return nil
            }
            return library
            
        case .Tmp:
            return FileManager.default.temporaryDirectory
        }
    }
    
}
